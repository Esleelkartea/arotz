/*  ArotzGest
 *  (c) 2006 Webalianza T.I S.L.
 *  Licenciado bajo la GNU General Public License
 *  
 *  Programaci�n: Jorge Moreiro
 *                Iker Est�banez
 * 
 *  Este fichero forma parte de ArotzGest
 *
 * ArotzGest es software libre; puede redistribuirlo y/o modificarlo
 * bajo los t�rminos de la GNU General Public License, tal y como se haya
 * publicada por la Free Software Foundation, en la versi�n 2 de la licencia o
 * (seg�n su elecci�n) cualquier versi�n posterior.
 * 
 * ArotzGest es redistribuido con la intenci�n que sea �til, pero SIN NINGUNA
 * GARANT�A, ni tan solo las garant�as impl�citas de MERCANTABILIDA o ADECUACI�N 
 * A UN DETERMINADO MOTIVO. Lea la GNU General Public License para m�s detalles.
 * 
 * Deber�a haber recibido una copia de la GNU General Public License acompa�ando a 
 * ArotzGest.
 * 
 * �STE PROYECTO HA SIDO SUBVENCIONADO POR SPRI S.A. DENTRO DEL MARCO DEL PROGRAMA
 * KZ LANKIDETZA - m�s informaci�n en http://www.spri.es
 * 
 *
 * */

using System;
using System.Drawing;
using System.Windows.Forms;

class InvoiceSearchTabPage : TabPage {
  Button acceptButton, cancelButton, createButton, detailButton, searchButton;
  ComboBox clientComboBox, monthComboBox, yearComboBox, stateComboBox;
  ListView itemListView;
  public InvoiceSearchTabPage () {
    Name = "invoiceSearch";
    Text = "Facturas";
    acceptButton = Interface.Button_Create (acceptButton_Click);
    Interface.HeaderPanel_Create (this, 0, 8, "Invoice", Text, "Buscar");
    Interface.Label_Create (this, 0, 48, "Cliente");
    clientComboBox = Interface.ComboBox_Create (this, 128, 48, 128);
    Interface.ComboBox_AddItem (clientComboBox, "", true);
    foreach (Database.Client client in Database.Client.List ()) Interface.ComboBox_AddItem (clientComboBox, client, false);
    Interface.Label_Create (this, 0, 76, "Fecha");
    monthComboBox = Interface.ComboBox_Create (this, 128, 76, 64);
    Interface.ComboBox_AddItem (monthComboBox, "", true);
    foreach (string month in Database.Months) Interface.ComboBox_AddItem (monthComboBox, month, false);
    yearComboBox = Interface.ComboBox_Create (this, 224, 76, 24);
    Interface.ComboBox_AddItem (yearComboBox, "", true);
    while (yearComboBox.Items.Count < 50) Interface.ComboBox_AddItem (yearComboBox, (2000 + yearComboBox.Items.Count).ToString (), false);
    Interface.Label_Create (this, 0, 104, "Estado");
    stateComboBox = Interface.ComboBox_Create (this, 128, 104, 128);
    Interface.ComboBox_AddItem (stateComboBox, "", true);
    foreach (string state in Database.InvoiceStates) Interface.ComboBox_AddItem (stateComboBox, state, false);
    searchButton = Interface.Button_Create (this, 0, 132, "Buscar", searchButton_Click);
    itemListView = Interface.ListView_Create (this, 0, 172, 0, 0, itemListView_SelectedIndexChanged, itemListView_DoubleClick);
    Interface.ListView_AddColumnHeader (itemListView, 41, "N�mero");
    Interface.ListView_AddColumnHeader (itemListView, 192, "Cliente");
    Interface.ListView_AddColumnHeader (itemListView, 54, "Fecha");
    Interface.ListView_AddColumnHeader (itemListView, 64, "Estado");
    createButton = Interface.Button_Create (this, 0, 0, "Crear", createButton_Click);
    detailButton = Interface.Button_Create (this, 88, 0, "Detalle", detailButton_Click);
    detailButton.Enabled = false;
    cancelButton = Interface.Button_Create (this, 0, 0, "Cerrar", cancelButton_Click);
  }
  protected override void OnGotFocus (EventArgs e) {
    base.OnGotFocus (e);
    (TopLevelControl as MainForm).DefaultButtons_Set (acceptButton, cancelButton);
    (itemListView.Items.Count == 0 ? clientComboBox as Control : itemListView).Focus ();
  }
  protected override void OnResize (EventArgs e) {
    base.OnResize (e);
    itemListView.Size = new Size (Width, Height - itemListView.Top - 32);
    createButton.Top = Height - 24;
    detailButton.Top = Height - 24;
    cancelButton.Location = new Point (Width - 80, Height - 24);
  }
  void acceptButton_Click (object o, EventArgs e) {
    (!itemListView.ContainsFocus ? searchButton : detailButton).PerformClick ();
  }
  void cancelButton_Click (object o, EventArgs e) {
    Parent.Controls.Remove (this);
  }
  void createButton_Click (object o, EventArgs e) {
    (TopLevelControl as MainForm).InvoiceDetailTabPage_Open (0);
  }
  void detailButton_Click (object o, EventArgs e) {
    (TopLevelControl as MainForm).InvoiceDetailTabPage_Open ((int) itemListView.SelectedItems [0].Tag);
  }
  void itemListView_DoubleClick (object o, EventArgs e) {
    detailButton.PerformClick ();
  }
  void itemListView_SelectedIndexChanged (object o, EventArgs e) {
    detailButton.Enabled = itemListView.SelectedItems.Count > 0;
  }
  void searchButton_Click (object o, EventArgs e) {
    Interface.ListView_Clear (itemListView);
    int clientId = 0;
    if (clientComboBox.SelectedIndex > 0) clientId = (clientComboBox.SelectedItem as Database.Client).Id;
    int year = yearComboBox.SelectedIndex;
    if (year > 0) year += 2000;
    foreach (Database.Invoice item in Database.Invoice.Search (clientId, monthComboBox.SelectedIndex, year, stateComboBox.SelectedIndex - 1)) Interface.ListView_AddListViewItem (itemListView, new string [] { item.Number.ToString (), item.ClientName, Data.Date_Format (item.Date), Database.InvoiceStates [item.State] }, item.Id);
    if (itemListView.Items.Count > 0) itemListView.Focus ();
  }
}

