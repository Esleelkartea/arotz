�stos iconos han sido obtenidos de  http://www.iconaholic.com/downloads.html, 
basandose en el Set iCandy Junior.

El autor expresa en su p�gina web que el contenido es redistribuible bajo
la circunstancia de que no sea un producto de pago.
